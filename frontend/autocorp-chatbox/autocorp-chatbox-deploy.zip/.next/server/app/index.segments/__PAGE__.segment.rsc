1:"$Sreact.fragment"
2:I[99062,["/_next/static/chunks/12f1641c307e7f6f.js"],"default"]
3:I[97367,["/_next/static/chunks/4fd93823156e59e8.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"6eUgcDVdUoJeICCa4vsNi","rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/12f1641c307e7f6f.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
