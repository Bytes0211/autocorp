1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/4fd93823156e59e8.js"],"default"]
3:I[37457,["/_next/static/chunks/4fd93823156e59e8.js"],"default"]
0:{"buildId":"6eUgcDVdUoJeICCa4vsNi","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
